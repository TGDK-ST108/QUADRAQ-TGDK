#include "Default.hpp"

void DefaultConsoleAI::Log(const std::string& msg) {
    std::cout << "[DefaultAI] " << msg << std::endl;
}

void DefaultConsoleAI::LogError(const std::string& msg) {
    std::cerr << "[DefaultAI][ERROR] " << msg << std::endl;
}

std::string DefaultConsoleAI::Identify() const {
    return "DEFAULT_CONSOLE_AI";
}

std::string DefaultConsoleAI::GetStatusString() const {
    return "Idle and listening.";
}

void DefaultConsoleAI::OnFrameStart() {}
void DefaultConsoleAI::OnFrameEnd() {}
void DefaultConsoleAI::OnInterceptEvent(const std::string&) {}
void DefaultConsoleAI::Shutdown() {}

bool DefaultConsoleAI::Initialize() {
    return true;
}

void DefaultConsoleAI::OnFrame() {}

bool DefaultConsoleAI::IsOliviaActive() const {
    return false;
}

bool DefaultConsoleAI::ShouldSuppressDraw(float) {
    return false;
}
