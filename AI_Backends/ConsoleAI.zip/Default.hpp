#pragma once

#include "TGDK_IAIBackend.hpp"
#include <iostream>

class DefaultConsoleAI : public IAIBackend {
public:
    DefaultConsoleAI() = default;
    ~DefaultConsoleAI() override = default;

    // Core IAIBackend interface
    void Log(const std::string& msg) override;
    void LogError(const std::string& msg) override;
    std::string Identify() const override;
    std::string GetStatusString() const override;
    void OnFrameStart() override;
    void OnFrameEnd() override;
    void OnInterceptEvent(const std::string&) override;
    void Shutdown() override;

    // Additional implementation functions
    virtual std::string Query(const std::string& input) = 0;

    bool Initialize();
    void OnFrame() override;
    bool IsOliviaActive() const override;
    bool ShouldSuppressDraw(float frameTime) override;
};
// Implementation of DefaultConsoleAI methods
void DefaultConsoleAI::Log(const std::string& msg) {
    std::cout << "[DefaultAI] " << msg << std::endl;
}
void DefaultConsoleAI::LogError(const std::string& msg) {
    std::cerr << "[DefaultAI][ERROR] " << msg << std::endl;
}
std::string DefaultConsoleAI::Identify() const {
    return "DefaultConsoleAI";
}
std::string DefaultConsoleAI::GetStatusString() const {
    return "Default Console AI Backend Active";
}
void DefaultConsoleAI::OnFrameStart() {
    Log("Frame started.");
}
void DefaultConsoleAI::OnFrameEnd() {
    Log("Frame ended.");
}
void DefaultConsoleAI::OnInterceptEvent(const std::string& event) {
    Log("[Intercepted] " + event);
}
void DefaultConsoleAI::Shutdown() {
    Log("Shutting down.");
}
bool DefaultConsoleAI::Initialize() {
    Log("Initializing Default Console AI Backend...");
    return true; // Assume initialization is always successful
}
void DefaultConsoleAI::OnFrame() {
    Log("Processing frame...");
}
bool DefaultConsoleAI::IsOliviaActive() const {
    return false; // Default implementation does not use Olivia
}
bool DefaultConsoleAI::ShouldSuppressDraw(float frameTime) {
    return false; // Default implementation does not suppress draws
}
std::string DefaultConsoleAI::Query(const std::string& input) {
    return "[DefaultAI] Query received : " + input;
}
// Factory function to create an instance of DefaultConsoleAI
extern "C" __declspec(dllexport) IAIBackend* CreateAIBackend() {
    return new DefaultConsoleAI();
}
//         overriddenShaders.push_back(newShader);
//
//         if (gAIBackendPtr)
//             gAIBackendPtr->Log("ShaderOverrideUnit :: Custom pixel shader applied.");
//     }
//
//     void ClearOverrides() {
//         std::lock_guard<std::mutex> lock(shader_mutex);
//
//         for (auto shader : overriddenShaders) {
//             if (shader) shader->Release();
//         }
    
//         overriddenShaders.clear();
//         if (gAIBackendPtr)
//             gAIBackendPtr->Log("ShaderOverrideUnit :: All shader overrides cleared.");
//     }
//         return true;
//     }
//
//     void SetEnabled(bool enable) {
//         std::lock_guard<std::mutex> lock(stateMutex);
//         overrideEnabled = enable;
//
//         if (enable) {
//             if (!hookInitialized && (!g_device || !g_context)) {
//                 if (gAIBackendPtr)
//                     gAIBackendPtr->LogError("ShaderOverrideUnit :: Cannot enable - pipeline not hooked.");
//                 return;
//             }
//             if (gAIBackendPtr)
//                 gAIBackendPtr->Log("ShaderOverrideUnit :: Shader overrides ENABLED.");
//         } else {
//             ClearOverrides();
//             if (gAIBackendPtr)
//                 gAIBackendPtr->Log("ShaderOverrideUnit :: Shader overrides DISABLED.");
//         }
//     }
//
//     bool IsEnabled() {
//         std::lock_guard<std::mutex> lock(stateMutex);
//         return overrideEnabled;
//     }
//
//     void OverridePixelShader(ID3D11PixelShader* newShader) {
//         std::lock_guard<std::mutex> lock(shader_mutex);
//
//         if (!g_context || !newShader) return;
//
//         g_context->PSSetShader(newShader, nullptr, 0);
//         overriddenShaders.push_back(newShader);
//
//         if (gAIBackendPtr)
//             gAIBackendPtr->Log("ShaderOverrideUnit :: Custom pixel shader applied.");
//     }
//
//     void ClearOverrides() {
//         std::lock_guard<std::mutex> lock(shader_mutex);
//
//         for (auto shader : overriddenShaders) {
//             if (shader) shader->Release();
//         }
//         overriddenShaders.clear();
//         if (gAIBackendPtr)
//             gAIBackendPtr->Log("ShaderOverrideUnit :: Cleared all shader overrides.");
//     }
//
//     return true;
//     }
//     if (gAIBackendPtr)
//         gAIBackendPtr->Log("FlatDDSInterceptor :: Cleared overrides.");
//     }
//     }
//     return true;
//     return "[DefaultAI] Default query handler.";