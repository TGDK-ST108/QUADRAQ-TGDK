/* ====================================================================
//                        ConsoleAI.hpp
//      Fallback Console-Based AI Backend for QUADRAQ
// ====================================================================*/

#pragma once
#include "TGDK_IAIBackend.hpp"
#include <iostream>
#include <string>

class ConsoleAI : public IAIBackend {
public:
	bool Initialize();
	virtual void OnFrame() = 0;
	virtual void Log(const std::string& msg) = 0;
	virtual void LogError(const std::string& msg) = 0;
	virtual bool IsOliviaActive() const = 0;
	virtual bool ShouldSuppressDraw(float entropy) = 0;
	virtual std::string Identify() const = 0;
	virtual std::string GetStatusString() const = 0;

	virtual std::string GetBackendName() const override {
		return "ConsoleAI";
	}
	virtual void OnFrameStart() override {
		Log("[ConsoleAI] Frame started.");
	}
	virtual void OnFrameEnd() override {
		Log("[ConsoleAI] Frame ended.");
	}
	virtual void OnInterceptEvent(const std::string& event) override {
		Log("[ConsoleAI] Intercepted event: " + event);
	}
	virtual void Shutdown() override {
		Log("[ConsoleAI] Shutting down.");
	}
	virtual std::string Query(const std::string& input) override {
		return "[Console
			AI] Default query handler : " + input;
	}	
};
	

