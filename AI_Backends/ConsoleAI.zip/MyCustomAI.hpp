#pragma once

#include "TGDK_IAIBackend.hpp"  // or "IAIBackend.hpp" if that's the file
#include <vector>

namespace QUADRAQ {

    class MyCustomAI : public IAIBackend {
    public:
        MyCustomAI();
		~MyCustomAI() override = default;
        bool Initialize();
		void run() override;
		void setInput(const std::vector<float>& input);
		std::vector<float> getOutput() const override;
		void Log(const std::string& msg) override;
		void LogError(const std::string& msg) override;
		bool IsOliviaActive() const override;
		bool ShouldSuppressDraw(float entropy) override;
		std::string Identify() const override;
		std::string GetStatusString() const override;
		void OnFrameStart() override;
        void OnFrame() override;
        virtual bool Initialize() = 0;
        virtual void OnFrame() = 0;
        virtual void Log(const std::string& msg) = 0;
        virtual void LogError(const std::string& msg) = 0;
        virtual bool IsOliviaActive() const = 0;
        virtual bool ShouldSuppressDraw(float entropy) = 0;
        virtual std::string Identify() const = 0;
        virtual std::string GetStatusString() const = 0;

    private:
        std::vector<float> inputData;
        std::vector<float> outputData;

        void compute();
    };

} // namespace QUADRAQ
